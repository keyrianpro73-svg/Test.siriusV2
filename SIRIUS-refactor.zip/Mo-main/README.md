# SNCK — SIRIUS

Application web de gestion des sillons, conduite, comptes et perturbations du réseau SNCK.

## Structure

- `index.html` : structure des écrans de l'application.
- `assets/app.js` : logique applicative, authentification, gestion des sillons et synchronisation.
- `assets/sirius.css` : couche de styles responsive ajoutée au design existant.
- `netlify/functions/db.mjs` : point d'accès de stockage Netlify Blobs (`/api/db`).
- `netlify.toml` : configuration Netlify.
- `package.json` : dépendance `@netlify/blobs`.

## Déploiement Netlify

1. Depuis ce dossier, exécuter `npm install`.
2. Exécuter `npx netlify login`, puis `npx netlify link` et sélectionner le site Netlify voulu.
3. Exécuter `npx netlify deploy --prod`.
4. Ouvrir le site et activer la synchronisation en ligne, ou rejoindre l'espace existant avec son code de synchronisation.

Le glisser-déposer du dossier n'installe pas les dépendances de la fonction Netlify.

## Notes

- Le système de connexion existant et la synchronisation par code ont été conservés.
- Le mode local reste disponible sans espace cloud configuré.
- Le fichier de données Netlify Blobs est hébergé séparément du ZIP : ce ZIP contient le code du projet, pas les données hébergées ni les variables d'environnement du compte Netlify.
- Le code d'espace de synchronisation doit être partagé uniquement avec les personnes autorisées à accéder aux données de cet espace.
