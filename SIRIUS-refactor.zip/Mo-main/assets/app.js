/* SIRIUS — logique applicative principale. Connexion et synchronisation par code conservées. */
// Comptes (chargés depuis le serveur, réservé à l'administrateur)
        let accountsState = [];
        let currentUser = null;
        let currentUserIsAdmin = false;
        let sillonsState = JSON.parse(localStorage.getItem('snck_sillons')) || [];
        let activeSillonIndex = null;
        let pendingPriseIndex = null;
        let heureArriveeFinaleReelle = null;
        let heureArriveeFinaleTs = null;
        let serviceAtteintTerminus = false;
        let currentPlatform = 'pc';

let cloudVersion = null;
let cloudBase = { sillons: [], perturbations: [] };
let cloudReady = false;
let cloudBusy = false;
let cloudDirty = false;
let cloudTimer;
const oldAccounts = JSON.parse(localStorage.getItem('snck_accounts') || '[]');
localStorage.removeItem('snck_current_user');
function setCloudStatus(state, message) {
    const badge = document.getElementById('cloud-status-badge');
    if (!badge) return;
    const s = ({
        online: [dbBase() ? 'Cloud synchronisé' : 'Mode local (cet appareil)', 'text-emerald-400 border-emerald-500/30'],
        connecting: ['Synchronisation…', 'text-blue-400 border-blue-500/30'],
        error: ['Non synchronisé — nouvelle tentative automatique', 'text-red-400 border-red-500/30'],
        offline: ['Connexion requise', 'text-gray-400 border-gray-500/30']
    })[state] || ['—', 'text-gray-400 border-gray-500/30'];
    badge.innerHTML = '<i class="fa-solid fa-cloud mr-1"></i>' + s[0];
    badge.title = message || '';
    badge.className = 'fixed bottom-3 right-3 z-40 px-3 py-1.5 rounded-full text-[11px] font-semibold border backdrop-blur bg-snck-dark ' + s[1];
}
// ====== Stockage : espace en ligne (fonction Netlify + Netlify Blobs) ou mode local ======
// Optionnel : colle ici le code de synchro (affiché dans l'écran admin) pour que tous les appareils l'utilisent d'office.
const DB_ID = '';
const BLOB = '/api/db';
const ADMIN_NAME = 'Keke73';
function dbBase() { return (localStorage.getItem('snck_db_id') || DB_ID).trim(); }
(function () { // lien de partage : index.html#sync=CODE
    const m = location.hash.match(/sync=([\w-]+)/);
    if (m) { localStorage.setItem('snck_db_id', m[1]); history.replaceState(null, '', location.pathname + location.search); }
})();
const apiErr = (message, status) => { const e = new Error(message); e.status = status; return e; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const toHex = bytes => Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
const hexKey = s => toHex(new TextEncoder().encode(String(s).trim().toLowerCase()));

async function blobFetch(method, body) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 15000);
    try {
        const r = await fetch(BLOB + '?id=' + encodeURIComponent(dbBase()), {
            method, cache: 'no-store', signal: ctrl.signal,
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: body === undefined ? undefined : JSON.stringify(body)
        });
        if (r.status === 404) throw apiErr('Espace de synchronisation introuvable (code invalide ou supprimé).', 502);
        if (!r.ok) throw apiErr('Erreur du service de synchronisation (' + r.status + ').', 502);
        const data = await r.json().catch(() => null);
        if (method === 'GET' && (data === null || typeof data !== 'object')) throw apiErr('Réponse inattendue du service de synchronisation.', 502);
        return data;
    } catch (e) {
        if (e.status) throw e;
        throw apiErr(e.name === 'AbortError' ? 'Le service de synchronisation ne répond pas (délai dépassé).' : 'Connexion au service de synchronisation impossible.', 0);
    } finally { clearTimeout(timer); }
}
// Tout le stockage est un seul document JSON : lecture, modification, réécriture
async function dbReq(method, path, value, shallow) {
    if (!dbBase()) return localDb(method, path, value, shallow);
    const root = await blobFetch('GET');
    const res = treeOp(root, method, path, value, shallow);
    if (method !== 'GET') await blobFetch('PUT', root);
    return res;
}
function treeOp(root, method, path, value, shallow) {
    const parts = path.split('/').filter(Boolean);
    let node = root;
    for (const p of parts.slice(0, -1)) {
        if (typeof node[p] !== 'object' || node[p] === null) { if (method !== 'PUT') return null; node[p] = {}; }
        node = node[p];
    }
    const last = parts[parts.length - 1];
    if (method === 'GET') {
        const v = node[last] === undefined ? null : node[last];
        return shallow && v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).map(k => [k, true])) : v;
    }
    if (method === 'PUT') node[last] = value; else delete node[last];
    return method === 'PUT' ? value : null;
}
function localDb(method, path, value, shallow) {
    const root = JSON.parse(localStorage.getItem('snck_localdb') || '{}');
    const res = treeOp(root, method, path, value, shallow);
    if (method !== 'GET') localStorage.setItem('snck_localdb', JSON.stringify(root));
    return res;
}

// ---- Comptes : seuls un sel et un hash PBKDF2 sont stockés, jamais le mot de passe ----
async function hashPwd(pwd, salt) {
    if (!crypto.subtle) throw apiErr('Le chiffrement du navigateur nécessite une page en HTTPS.', 500);
    const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pwd), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 150000, hash: 'SHA-256' }, k, 256);
    return toHex(new Uint8Array(bits));
}
async function creerCompte(name, pwd, admin) {
    const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
    const acc = { id: name, salt, hash: await hashPwd(pwd, salt), admin: !!admin };
    await dbReq('PUT', 'accounts/' + hexKey(name), acc);
    return acc;
}
async function sessionUser() {
    const name = localStorage.getItem('snck_session');
    if (!name) return null;
    const acc = await dbReq('GET', 'accounts/' + hexKey(name));
    return acc ? { name: acc.id, admin: acc.admin === true } : null; // compte supprimé => session invalide
}

// ---- Routes (mêmes noms que l'ancienne API : le reste de la page ne change pas) ----
async function api(path, method = 'GET', body) {
    try { return await route(path, method, body || {}); }
    catch (e) {
        if (e.status === 401 && path !== 'login' && path !== 'session' && currentUser) sessionExpiree();
        throw e;
    }
}
async function route(path, method, body) {
    if (path === 'login' && method === 'POST') {
        const name = String(body.name || '').trim(), pwd = String(body.password || '');
        if (!name) throw apiErr('Identifiant requis.', 400);
        let acc = await dbReq('GET', 'accounts/' + hexKey(name));
        if (!acc && name.toLowerCase() === ADMIN_NAME.toLowerCase() && !(await dbReq('GET', 'accounts', undefined, true))) {
            if (pwd.length < 6) throw apiErr('Premier lancement : choisis un mot de passe de 6 caractères minimum.', 400);
            acc = await creerCompte(ADMIN_NAME, pwd, true); // le tout premier mot de passe devient celui de l'admin
        } else if (!acc || await hashPwd(pwd, acc.salt) !== acc.hash) {
            await sleep(600);
            throw apiErr('Identifiant ou mot de passe incorrect.', 401);
        }
        localStorage.setItem('snck_session', acc.id);
        return { name: acc.id, admin: acc.admin === true };
    }
    if (path === 'logout') { localStorage.removeItem('snck_session'); return { ok: true }; }
    const user = await sessionUser();
    if (!user) throw apiErr('Session absente ou expirée.', 401);
    if (path === 'session') return user;

    if (path === 'state' && method === 'GET') {
        const s = await dbReq('GET', 'state');
        let data = s || {};
        if (s && s.json) { try { data = JSON.parse(s.json); } catch {} }
        return { sillons: data.sillons || [], perturbations: data.perturbations || [], version: s ? s.version : null, admin: user.admin };
    }
    if (path === 'state' && method === 'PUT') {
        if (!Array.isArray(body.sillons) || !Array.isArray(body.perturbations)) throw apiErr('Données invalides.', 400);
        const cur = await dbReq('GET', 'state');
        if ((cur ? cur.version : null) !== (body.version ?? null)) throw apiErr('Conflit de version.', 409);
        const version = (cur ? cur.version : 0) + 1;
        const w = toHex(crypto.getRandomValues(new Uint8Array(6)));
        await dbReq('PUT', 'state', { sillons: body.sillons, perturbations: body.perturbations, version, w });
        const chk = await dbReq('GET', 'state'); // relecture : si un autre appareil a écrit en même temps, on signale un conflit
        if (!chk || chk.w !== w) throw apiErr('Conflit de version.', 409);
        return { version };
    }
    if (path === 'sillons' && method === 'GET') return (await route('state', 'GET', {})).sillons;

    if (path === 'accounts') {
        if (!user.admin) throw apiErr("Réservé à l'administrateur.", 403);
        const all = (await dbReq('GET', 'accounts')) || {};
        if (method === 'GET') return Object.values(all).map(a => ({ id: a.id, admin: a.admin === true })).sort((a, b) => (b.admin === true) - (a.admin === true));
        const name = String(body.name || '').trim();
        if (method === 'POST') {
            const password = String(body.password || '');
            if (!/^[\p{L}\p{N}_.\- ]{2,32}$/u.test(name)) throw apiErr('Identifiant invalide (2 à 32 caractères : lettres, chiffres, _ . -).', 400);
            if (password.length < 6) throw apiErr('Mot de passe : 6 caractères minimum.', 400);
            if (all[hexKey(name)]) throw apiErr('Cet identifiant existe déjà.', 409);
            await creerCompte(name, password, false);
            return { ok: true };
        }
        if (method === 'DELETE') {
            const acc = all[hexKey(name)];
            if (acc && acc.admin) throw apiErr("Le compte administrateur ne peut pas être supprimé.", 400);
            await dbReq('DELETE', 'accounts/' + hexKey(name));
            return { ok: true };
        }
    }
    throw apiErr('Route introuvable (' + path + ').', 404);
}

// ---- Affichage de la base dans l'écran admin / connexion ----
function urlApiSillons() { return dbBase() ? location.origin + BLOB + '?id=' + dbBase() : ''; }
function lienSync() { return dbBase() ? location.href.split('#')[0] + '#sync=' + dbBase() : ''; }



function configurerCloud() {
    const v = prompt("Code ou lien de synchronisation à rejoindre (vide = mode local sur cet appareil) :", dbBase());
    if (v === null) return;
    const id = v.trim().replace(/^.*(sync=|\/)/, '');
    if (!/^[\w-]*$/.test(id)) { alert('Code invalide.'); return; }
    if (id) localStorage.setItem('snck_db_id', id); else localStorage.removeItem('snck_db_id');
    updateBucketIdDisplay(); setCloudStatus('offline');
}
async function creerEspaceCloud() {
    if (dbBase() && !confirm('Un espace est déjà configuré. En créer un nouveau ? (les autres appareils devront le rejoindre)')) return;
    try {
        const root = JSON.parse(localStorage.getItem('snck_localdb') || '{}'); // reprend les comptes et sillons de cet appareil
        const id = uuid();
        const r = await fetch(BLOB + '?id=' + encodeURIComponent(id), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(root) });
        if (!r.ok) throw new Error('Le service a répondu ' + r.status + (r.status === 404 ? ' (la fonction /api/db n\u2019est pas déployée ?)' : ''));
        localStorage.setItem('snck_db_id', id);
        updateBucketIdDisplay(); setCloudStatus('offline');
        prompt('Synchronisation activée. Ouvre ce lien sur tes autres appareils (copie-le, il est aussi dans l’écran admin) :', lienSync());
    } catch (e) { alert('Création impossible : ' + (e.message || e)); }
}
// Session expirée ou compte supprimé : retour à l'écran de connexion.
function sessionExpiree() {
    viderCachesLocaux();
    currentUser = null;
    currentUserIsAdmin = false;
    cloudReady = false;
    cloudDirty = false;
    accountsState = [];
    activeSillonIndex = null;
    setCloudStatus('offline');
    document.querySelectorAll('.fixed.inset-0').forEach(m => m.classList.add('hidden'));
    switchScreen('screen-auth');
    alert('Ta session a expiré. Reconnecte-toi.');
}
// Reprend la session existante (cookie) au rechargement de la page.
async function restaurerSession() {
    try {
        const session = await api('session');
        currentUser = session.name;
        currentUserIsAdmin = session.admin === true;
    } catch { switchScreen('screen-auth'); return; }
    try { await initializeCloud(); } catch (error) { setCloudStatus('error', error.message); }
    verifierAccesEtAfficherSelection();
}
function updateBucketIdDisplay() {
    document.getElementById('cloud-bucket-id').textContent = dbBase() || 'Mode local (aucun espace en ligne)';
    document.getElementById('api-url-sillons').textContent = urlApiSillons() || 'Active la synchronisation en ligne pour obtenir l’adresse';
    const ex = document.getElementById('api-example');
    if (ex) ex.textContent = urlApiSillons() ? `fetch('${urlApiSillons()}')\n  .then(r => r.json())\n  .then(data => console.log(data.state.sillons));` : '—';
    const l = document.getElementById('cloud-cfg-label');
    if (l) l.textContent = dbBase() ? 'en ligne (' + dbBase().slice(0, 8) + '…)' : 'locale (cet appareil)';
}
function copyApiUrl() { if (urlApiSillons()) copierTexte(urlApiSillons()); }
function copyBucketId() { if (lienSync()) copierTexte(lienSync()); }
function snapshot() { return JSON.parse(JSON.stringify({ sillons: sillonsState, perturbations: perturbationsState })); }
function mergeChanges(base, local, remote) {
    const result = {};
    for (const key of ['sillons', 'perturbations']) {
        const before = new Map(base[key].map(x => [String(x.id), x]));
        const after = new Map(local[key].map(x => [String(x.id), x]));
        const merged = new Map(remote[key].map(x => [String(x.id), x]));
        for (const id of before.keys()) if (!after.has(id)) merged.delete(id);
        for (const [id, item] of after) {
            if (!before.has(id)) merged.set(id, item);
            else if (merged.has(id) && JSON.stringify(before.get(id)) !== JSON.stringify(item)) {
                const next = { ...(merged.get(id) || item) };
                for (const field of new Set([...Object.keys(before.get(id)), ...Object.keys(item)])) {
                    if (JSON.stringify(before.get(id)[field]) !== JSON.stringify(item[field])) {
                        if (field in item) next[field] = item[field]; else delete next[field];
                    }
                }
                merged.set(id, next);
            }
        }
        result[key] = [...merged.values()];
    }
    return result;
}
function applyState(data) {
    // Keep the active cab attached to its train when another device adds/deletes a service.
    const activeId = activeSillonIndex !== null ? sillonsState[activeSillonIndex]?.id : null;
    const pendingId = pendingPriseIndex !== null ? sillonsState[pendingPriseIndex]?.id : null;
    sillonsState = data.sillons || [];
    perturbationsState = data.perturbations || [];
    if (activeId !== null) {
        const index = sillonsState.findIndex(x => x.id === activeId);
        activeSillonIndex = index < 0 ? null : index;
        if (index < 0) switchScreen('screen-conduire');
    }
    if (pendingId !== null) {
        const index = sillonsState.findIndex(x => x.id === pendingId);
        pendingPriseIndex = index < 0 ? null : index;
        if (index < 0) closePriseServiceModal();
    }
    localStorage.setItem('snck_sillons', JSON.stringify(sillonsState));
    localStorage.setItem('snck_perturbations', JSON.stringify(perturbationsState));
    renderSillons(); renderSillonsConduite(); renderPerturbations();
    const sa = getActif();
    if (sa && sa.conducteur && sa.conducteur !== currentUser) {
        activeSillonIndex = null;
        document.getElementById('tel-btn-retour').style.display = 'flex';
        document.getElementById('pc-btn-retour').style.display = 'flex';
        switchScreen('screen-conduire');
        alert('Ce service a été pris par ' + sa.conducteur + '.');
    }
    if (activeSillonIndex !== null) { calculerHorairesParcours(); mettreAJourAffichageRetard(); updateBoutonConduiteUI(); }
}
function cloudSave(immediate) {
    cloudDirty = true;
    setCloudStatus('connecting');
    clearTimeout(cloudTimer);
    cloudTimer = setTimeout(flushCloud, immediate ? 0 : 400);
}
async function flushCloud() {
    if (!currentUser || !cloudReady || cloudBusy || !cloudDirty) return;
    cloudBusy = true;
    const sent = snapshot();
    try {
        const result = await api('state', 'PUT', { ...sent, version: cloudVersion });
        cloudVersion = result.version;
        cloudBase = sent;
        cloudDirty = JSON.stringify(snapshot()) !== JSON.stringify(sent);
        setCloudStatus(cloudDirty ? 'connecting' : 'online');
    } catch (error) {
        try {
        if (error.status === 409) {
            const remote = await api('state');
            const merged = mergeChanges(cloudBase, snapshot(), remote);
            cloudBase = { sillons: remote.sillons || [], perturbations: remote.perturbations || [] };
            cloudVersion = remote.version;
            applyState(merged);
        } else setCloudStatus('error');
        } catch { setCloudStatus('error'); }
    } finally {
        cloudBusy = false;
        if (cloudDirty) cloudTimer = setTimeout(flushCloud, 2000);
    }
}
async function cloudPull() {
    if (!currentUser || cloudBusy) return;
    if (!cloudReady) {
        cloudBusy = true;
        try { await initializeCloud(); }
        catch (error) { setCloudStatus('error', error.message); }
        finally { cloudBusy = false; }
        return;
    }
    if (cloudDirty) return;
    cloudBusy = true;
    try {
        const data = await api('state');
        currentUserIsAdmin = data.admin === true;
        if (cloudDirty) return;
        if (data.version !== cloudVersion) {
            cloudVersion = data.version;
            cloudBase = { sillons: data.sillons || [], perturbations: data.perturbations || [] };
            applyState(cloudBase);
        }
        if (data.admin) {
            try { accountsState = await api('accounts'); renderComptesList(); }
            catch (error) { document.getElementById('liste-comptes-container').title = error.message; }
        }
        setCloudStatus('online');
    } catch { setCloudStatus('error'); }
    finally { cloudBusy = false; }
}
async function initializeCloud() {
    const data = await api('state');
    currentUserIsAdmin = data.admin === true;
    cloudVersion = data.version;
    if (data.version === null && data.admin) {
        cloudReady = true;
        cloudDirty = true;
        await flushCloud();
    } else {
        cloudBase = { sillons: data.sillons || [], perturbations: data.perturbations || [] };
        applyState(cloudBase);
        cloudReady = true;
    }
    if (data.admin) {
        accountsState = await api('accounts');
        let importFailed = false;
        for (const account of oldAccounts) {
            if (account.pwd && !accountsState.some(x => x.id.toLowerCase() === account.id.toLowerCase())) {
                try {
                    await api('accounts', 'POST', { name: account.id, password: account.pwd });
                    accountsState.push({ id: account.id });
                } catch { importFailed = true; }
            }
        }
        if (!importFailed) { localStorage.removeItem('snck_accounts'); oldAccounts.length = 0; }
        else alert('Certains anciens comptes n’ont pas pu être importés. Leurs données locales sont conservées. Recrée-les dans la gestion des comptes avec un mot de passe de 6 caractères minimum.');
    }
    setCloudStatus(cloudDirty ? 'error' : 'online');
}
window.addEventListener('DOMContentLoaded', () => { updateBucketIdDisplay(); setCloudStatus('offline'); });
setInterval(() => { if (cloudDirty && cloudReady) flushCloud(); else cloudPull(); }, 5000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) { if (cloudDirty && cloudReady) flushCloud(); else cloudPull(); } });
window.addEventListener('online', () => { if (cloudDirty && cloudReady) flushCloud(); else cloudPull(); });
window.addEventListener('beforeunload', e => { if (cloudDirty) { e.preventDefault(); e.returnValue = ''; } });


  const ligneOrdre = ['Fontaine', 'Mairie', 'Hôpital', '*Stockage', '*Dépot', 'Ville'];
        const tempsTrajetSecondes = {
            'Fontaine->Mairie': 65, 'Mairie->Hôpital': 36, 'Hôpital->*Stockage': 25, '*Stockage->*Dépot': 8, '*Dépot->Ville': 16,
            'Ville->*Dépot': 16, '*Dépot->*Stockage': 8, '*Stockage->Hôpital': 25, 'Hôpital->Mairie': 36, 'Mairie->Fontaine': 65
        };

        window.addEventListener('DOMContentLoaded', () => {
            detecterPlateforme();
            restaurerSession();
        });

        async function handleAuth(e) {
            e.preventDefault();
            const name = document.getElementById('auth-username').value.trim();
            const password = document.getElementById('auth-password').value;
            const button = e.submitter;
            if (button) button.disabled = true;
            try {
                const result = await api('login', 'POST', { name, password });
                currentUser = result.name;
                currentUserIsAdmin = result.admin === true;
                try { await initializeCloud(); }
                catch (error) { setCloudStatus('error', error.message); }
                document.getElementById('auth-password').value = '';
                verifierAccesEtAfficherSelection();
            } catch (error) { currentUser = null; cloudReady = false; alert(error.message); }
            finally { if (button) button.disabled = false; }
        }

        function verifierAccesEtAfficherSelection() {
            document.getElementById('current-user-display').innerText = currentUser;
            
            // Afficher la gestion des comptes selon les droits vérifiés par le serveur.
            const grid = document.getElementById('modes-grid');
            const adminMenuId = 'admin-menu-card';
            let existingAdminCard = document.getElementById(adminMenuId);

            if (currentUserIsAdmin) {
                grid.className = "grid grid-cols-1 md:grid-cols-2 gap-6 pt-4";
                if (!existingAdminCard) {
                    let card = document.createElement('button');
                    card.id = adminMenuId;
                    card.onclick = () => openAdminComptesModule();
                    card.className = "group relative bg-snck-card border border-amber-500/30 hover:border-amber-500 p-8 rounded-2xl text-left transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/10 hover:-translate-y-1 cursor-pointer md:col-span-2";
                    card.innerHTML = `
                        <div class="absolute top-6 right-6 w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                            <i class="fa-solid fa-user-shield text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-2 text-amber-400">Gestion des Comptes (Admin)</h3>
                        <p class="text-gray-400 text-sm mb-4">Panneau exclusif pour créer, modifier ou supprimer les accès conducteurs.</p>
                        <span class="inline-flex items-center gap-2 text-amber-400 font-semibold text-sm">
                            Gérer les comptes <i class="fa-solid fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                        </span>`;
                    grid.appendChild(card);
                }
            } else {
                grid.className = "grid grid-cols-1 md:grid-cols-2 gap-6 pt-4";
                if (existingAdminCard) existingAdminCard.remove();
            }

            switchScreen('screen-selection');
        }

        async function deconnecterCompte() {
            if (cloudDirty) { await flushCloud(); if (cloudDirty) { alert('Synchronisation en attente. Réessaie avant de te déconnecter.'); return; } }
            try { await api('logout', 'POST'); } catch (error) { alert(error.message); return; }
            cloudReady = false;
            accountsState = [];
            setCloudStatus('offline');
            localStorage.removeItem('snck_current_user');
            currentUser = null;
            currentUserIsAdmin = false;
            viderCachesLocaux();
            document.getElementById('auth-username').value = '';
            document.getElementById('auth-password').value = '';
            switchScreen('screen-auth');
        }

        function openAdminComptesModule() {
            switchScreen('screen-admin-comptes');
            renderComptesList();
        }

        async function handleCreateAccount(e) {
            e.preventDefault();
            const name = document.getElementById('new-user-id').value.trim();
            const password = document.getElementById('new-user-pwd').value;
            const button = e.submitter;
            if (button) button.disabled = true;
            try {
                await api('accounts', 'POST', { name, password });
                accountsState = await api('accounts');
                document.getElementById('new-user-id').value = '';
                document.getElementById('new-user-pwd').value = '';
                renderComptesList();
            } catch (error) { alert(error.message); }
            finally { if (button) button.disabled = false; }
        }

        function renderComptesList() {
            const container = document.getElementById('liste-comptes-container');
            container.innerHTML = '';
            accountsState.forEach((acc, idx) => {
                let isKeke = acc.admin === true;
                container.innerHTML += `
                    <div class="bg-snck-dark border border-snck-border p-4 rounded-xl flex justify-between items-center text-sm">
                        <div>
                            <span class="font-bold text-blue-400">${escapeHtml(acc.id)}</span> 
                            <span class="text-xs text-gray-500 ml-2">Mot de passe protégé</span>
                            ${isKeke ? '<span class="ml-3 px-2 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">Admin Principal</span>' : ''}
                        </div>
                        ${!isKeke ? `<button onclick="deleteAccount(${idx})" class="px-3 py-1 bg-red-500/10 text-red-400 text-xs rounded-lg hover:bg-red-500/20 cursor-pointer">Supprimer</button>` : ''}
                    </div>`;
            });
        }

        async function deleteAccount(idx) {
            if (!confirm('Supprimer ce compte conducteur ?')) return;
            try {
                await api('accounts', 'DELETE', { name: accountsState[idx].id });
                accountsState = await api('accounts');
                renderComptesList();
            } catch (error) { alert(error.message); }
        }
        function escapeHtml(value) {
            const element = document.createElement('span'); element.textContent = String(value); return element.innerHTML;
        }

        function sauvegarderStorage(now) {
            localStorage.setItem('snck_sillons', JSON.stringify(sillonsState));
            cloudSave(now);
        }


        function formaterDateJJMM(dateStr) {
            if (!dateStr) return '--/--';
            let parts = dateStr.split('-');
            if (parts.length === 3) {
                return `${parts[2]}/${parts[1]}`;
            }
            return dateStr;
        }

        setInterval(() => {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('fr-FR');
            document.getElementById('pc-clock').innerText = timeStr;
            document.getElementById('tel-clock').innerText = timeStr;
            
            if (activeSillonIndex !== null && !serviceAtteintTerminus) {
                const sillonActif = sillonsState[activeSillonIndex];
                if (sillonActif) {
                    if (!sillonActif.isStarted) {
                        calculerRetardAutomatique(activeSillonIndex);
                    }
                    verifierHeureDepartAtteinte();
                }
                mettreAJourAffichageRetard(); // actualise l'avance/retard en haut des horaires chaque seconde
                verifierBoutonFinService();
            }
        }, 1000);

        

        // ====== Lignes du réseau ======
        // Ligne 2 : voie unique. ZC = Zone de Croisement, traitée comme une gare (arrêt possible pour croiser).
        const LIBELLES_GARES = { 'ZC': 'ZC (Zone Croisement)' };
        const LIGNES = {
            fontaine: { nom: 'Ligne Fontaine - Ville', ordre: ligneOrdre, temps: tempsTrajetSecondes, voieUnique: false },
            pavillon: {
                nom: 'Ligne Hôpital - Pavillon Noir',
                ordre: ['Hôpital', 'Ville', 'Zoo', 'ZC', 'Pavillon Noir'],
                temps: {
                    'Hôpital->Ville': 35, 'Ville->Zoo': 25, 'Zoo->ZC': 26, 'ZC->Pavillon Noir': 13,
                    'Ville->Hôpital': 35, 'Zoo->Ville': 25, 'ZC->Zoo': 26, 'Pavillon Noir->ZC': 13
                },
                voieUnique: true
            }
        };
        // Voies possibles par gare sur la ligne Hôpital - Pavillon Noir
        const VOIES_PAVILLON = {
            'Hôpital': ['Voie C', 'Voie D'],
            'Ville': ['Voie C', 'Voie D'],
            'Zoo': ['Voie A', 'Voie B'],
            'Pavillon Noir': ['Voie A', 'Voie B']
        };
        // Les sillons créés avant l'ajout des lignes n'ont pas de champ "ligne" : ils restent sur Fontaine - Ville.
        function ligneDe(s) { return LIGNES[s && s.ligne] || LIGNES.fontaine; }

        function changerLigne() {
            const L = ligneDe({ ligne: document.getElementById('sillon-ligne').value });
            const opts = L.ordre.map(g => `<option value="${g}">${escapeHtml(LIBELLES_GARES[g] || g)}</option>`).join('');
            const o = document.getElementById('sillon-origine'), t = document.getElementById('sillon-terminus');
            o.innerHTML = opts; t.innerHTML = opts;
            o.value = L.ordre[0]; t.value = L.ordre[L.ordre.length - 1];
            document.getElementById('arrets-container').innerHTML = L.ordre.slice(1, -1).map(g => `
                <div class="flex items-center justify-between bg-snck-dark p-3 rounded-xl border border-snck-border">
                    <label class="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" name="arret-inter" value="${g}" class="rounded bg-snck-dark border-snck-border text-blue-500"> ${escapeHtml(LIBELLES_GARES[g] || g)}</label>
                    <input type="number" id="arret-duree-${g}" min="0" value="1" class="w-20 bg-snck-card border border-snck-border rounded-lg px-2 py-1 text-xs text-white text-center">
                </div>`).join('');
            updateVoiesOptions();
        }

        function updateVoiesOptions() {
            const ligneOrdre = ligneDe({ ligne: document.getElementById('sillon-ligne').value }).ordre;
            const origine = document.getElementById('sillon-origine').value;
            const terminus = document.getElementById('sillon-terminus').value;
            const ligneCle = document.getElementById('sillon-ligne').value;
            const estPavillon = ligneCle === 'pavillon';
            document.getElementById('container-voie-fontaine').style.display = (!estPavillon && (origine === 'Fontaine' || terminus === 'Fontaine')) ? 'block' : 'none';
            document.getElementById('container-voie-ville').style.display = (!estPavillon && (() => { const a = ligneOrdre.indexOf(origine), b = ligneOrdre.indexOf(terminus), v = ligneOrdre.indexOf('Ville'); return v >= Math.min(a, b) && v <= Math.max(a, b); })()) ? 'block' : 'none';
            const iO = ligneOrdre.indexOf(origine), iT = ligneOrdre.indexOf(terminus), lo = Math.min(iO, iT), hi = Math.max(iO, iT);
            // Ligne Hôpital - Pavillon Noir : choix de la voie dans chaque gare du parcours (ZC = croisement, sans voie)
            document.getElementById('container-voies-pavillon').style.display = estPavillon ? 'grid' : 'none';
            Object.keys(VOIES_PAVILLON).forEach(g => {
                const i = ligneOrdre.indexOf(g);
                document.getElementById('cv-pav-' + g).style.display = (estPavillon && i >= lo && i <= hi) ? 'block' : 'none';
            });
            document.querySelectorAll('input[name="arret-inter"]').forEach(cb => {
                const i = ligneOrdre.indexOf(cb.value), ok = i > lo && i < hi;
                cb.disabled = !ok; if (!ok) cb.checked = false;
                cb.closest('div.flex').classList.toggle('opacity-40', !ok);
            });
        }

        function switchScreen(screenId) {
            document.querySelectorAll('.app-screen').forEach(s => s.classList.add('hidden'));
            document.getElementById(screenId).classList.remove('hidden');
            const b = document.getElementById('cloud-status-badge');
            if (b) b.style.display = screenId === 'screen-cabine-tel' ? 'none' : '';
        }

        function openCreateSillonModule() {
            currentPlatform = 'pc';
            switchScreen('screen-create-sillon');
            changerLigne();
            updateVoiesOptions();
            renderSillons();
        }

        function openConduireModule(platform) {
            currentPlatform = platform || 'pc';
            switchScreen('screen-conduire');
            renderSillonsConduite();
        }

        function retourMenuConduite() {
            if (currentPlatform === 'tel') {
                switchScreen('screen-tel-menu');
            } else {
                switchScreen('screen-pc-menu');
            }
        }

        function handleCreateSillon(e) {
            e.preventDefault();
            const numero = document.getElementById('sillon-numero').value.trim();
            const dateBrute = document.getElementById('sillon-date').value;
            const dateJJMM = formaterDateJJMM(dateBrute);
            const depart = document.getElementById('sillon-depart-heure').value;
            const composition = document.getElementById('sillon-composition').value;
            const origine = document.getElementById('sillon-origine').value;
            const terminus = document.getElementById('sillon-terminus').value;
            const voieFontaine = document.getElementById('voie-fontaine').value;
            const voieVille = document.getElementById('voie-ville').value;
            const ligne = document.getElementById('sillon-ligne').value;
            const ligneOrdre = ligneDe({ ligne }).ordre;
            if (origine === terminus) { alert("L'origine et le terminus doivent être différents."); return; }
            if (sillonsState.some(x => String(x.numero).toLowerCase() === numero.toLowerCase() && x.dateBrute === dateBrute)) { alert('Un sillon avec ce numéro existe déjà à cette date.'); return; }
            const iO = ligneOrdre.indexOf(origine), iT = ligneOrdre.indexOf(terminus), lo = Math.min(iO, iT), hi = Math.max(iO, iT);

            const checkboxes = document.querySelectorAll('input[name="arret-inter"]:checked');
            let arretsInter = [];
            let arretsDurees = {};
            checkboxes.forEach(cb => {
                const i = ligneOrdre.indexOf(cb.value); if (i <= lo || i >= hi) return;
                arretsInter.push(cb.value);
                arretsDurees[cb.value] = parseInt(document.getElementById(`arret-duree-${cb.value}`).value) || 0;
            });

            const voies = {};
            if (ligne === 'pavillon') {
                Object.keys(VOIES_PAVILLON).forEach(g => {
                    const i = ligneOrdre.indexOf(g);
                    if (i >= lo && i <= hi) voies[g] = document.getElementById('voie-pav-' + g).value;
                });
            }

            sillonsState.push({
                id: uuid(), numero, ligne, dateBrute, dateJJMM, depart, composition, origine, terminus, voieFontaine, voieVille, voies,
                arretsInter, arretsDurees, statut: 'Libre', retard: 0, retardManuel: 0, isStarted: false, motifRetard: ''
            });

            sauvegarderStorage();
            document.getElementById('form-sillon').reset();
            document.getElementById('sillon-ligne').value = ligne;
            changerLigne();
            updateVoiesOptions();
            renderSillons();
        }

        function renderSillons() {
            const container = document.getElementById('liste-sillons');
            document.getElementById('sillons-count').innerText = `${sillonsState.length} sillon${sillonsState.length > 1 ? 's' : ''} actif${sillonsState.length > 1 ? 's' : ''}`;
            if (sillonsState.length === 0) {
                container.innerHTML = `<div class="text-center py-12 bg-snck-card border border-snck-border rounded-2xl text-gray-400">Aucun sillon prévu.</div>`;
                return;
            }
            container.innerHTML = '';
            sillonsState.forEach((sillon, index) => {
                let parcours = `${sillon.origine} ➔ ${sillon.arretsInter.length ? sillon.arretsInter.join(' ➔ ') + ' ➔ ' : ''}${sillon.terminus}`;
                container.innerHTML += `
                    <div class="bg-snck-card border border-snck-border rounded-2xl p-5 flex justify-between items-center">
                        <div class="space-y-1 text-sm">
                            <div>
                                <span class="px-2.5 py-0.5 rounded bg-blue-500/10 text-blue-400 font-mono font-bold">${escapeHtml(sillon.numero)}</span> 
                                <span class="ml-2 font-semibold text-indigo-300">[${escapeHtml(sillon.dateJJMM)}]</span>
                                <span class="ml-2 font-semibold">Départ : ${escapeHtml(sillon.depart)}</span>
                                <span class="ml-3 px-2 py-0.5 rounded text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">${escapeHtml(sillon.statut)}</span>
                            </div>
                            <div class="text-xs text-gray-400">Composition : ${escapeHtml(sillon.composition)}</div>
                            <div class="text-xs text-gray-400">Ligne : ${escapeHtml(ligneDe(sillon).nom)}</div>
                            <div class="text-xs text-gray-400">Parcours : ${escapeHtml(parcours)}</div>
                        </div>
                        <button onclick="deleteSillon(${index})" class="px-3 py-1.5 bg-red-500/10 text-red-400 text-xs rounded-lg cursor-pointer hover:bg-red-500/20">Supprimer</button>
                    </div>`;
            });
        }

        function renderSillonsConduite() {
            const container = document.getElementById('liste-sillons-conduite');
            if (sillonsState.length === 0) {
                container.innerHTML = `<div class="text-center py-12 bg-snck-dark border border-snck-border rounded-2xl text-gray-400">Aucun sillon disponible.</div>`;
                return;
            }
            container.innerHTML = '';
            sillonsState.forEach((sillon, index) => {
                let isOccuped = (sillon.statut === 'En Service');
                let isSupprime = (sillon.statut === 'Supprimé' || sillon.serviceSupprime);
                let parcours = `${sillon.origine} ➔ ${sillon.arretsInter.length ? sillon.arretsInter.join(' ➔ ') + ' ➔ ' : ''}${sillon.terminus}`;

                let badgeStatut = '';
                let opacityClass = '';
                let textBarre = '';
                let btnAction = '';

                if (isSupprime) {
                    badgeStatut = `<span class="px-2 py-0.5 rounded text-xs bg-red-500/10 text-red-400 border border-red-500/20 font-bold">Service supprimé</span>`;
                    opacityClass = 'opacity-40';
                    textBarre = 'line-through';
                    btnAction = `<button disabled class="px-4 py-2 rounded-xl bg-gray-800 text-gray-600 cursor-not-allowed text-xs font-semibold"><i class="fa-solid fa-ban mr-1"></i> Indisponible</button>`;
                } else if (isOccuped) {
                    badgeStatut = `<span class="px-2 py-0.5 rounded text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">En Service</span>`;
                    opacityClass = (sillon.conducteur || currentUser) === currentUser ? '' : 'opacity-50';
                    btnAction = (sillon.conducteur || currentUser) === currentUser
                        ? `<button onclick="reprendreService(${index})" class="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white cursor-pointer text-xs font-semibold">Reprendre</button>`
                        : `<button disabled class="px-4 py-2 rounded-xl bg-gray-800 text-gray-500 cursor-not-allowed text-xs font-semibold">Occupé</button>`;
                } else {
                    badgeStatut = `<span class="px-2 py-0.5 rounded text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">Libre</span>`;
                    btnAction = `<button onclick="ouvrirPriseServiceModal(${index})" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer text-xs font-semibold">Je fais ce service</button>`;
                }

                container.innerHTML += `
                    <div class="bg-snck-dark border border-snck-border rounded-2xl p-4 flex justify-between items-center ${opacityClass}">
                        <div class="space-y-1 text-sm">
                            <div>
                                <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono font-bold ${textBarre}">${escapeHtml(sillon.numero)}</span>
                                <span class="ml-2 text-indigo-300 font-semibold ${textBarre}">[${escapeHtml(sillon.dateJJMM)}]</span>
                                <span class="ml-2 font-semibold ${textBarre}">Départ : ${escapeHtml(sillon.depart)}</span>
                                ${badgeStatut}
                            </div>
                            <div class="text-xs text-gray-400 ${textBarre}">Parcours : ${escapeHtml(parcours)}</div>
                        </div>
                        ${btnAction}
                    </div>`;
            });
        }

        function ouvrirPriseServiceModal(index) {
            pendingPriseIndex = index;
            document.getElementById('prise-service-details').innerText = `Sillon ${sillonsState[index].numero} (Date: ${sillonsState[index].dateJJMM} - ${sillonsState[index].origine} ➔ ${sillonsState[index].terminus})`;
            document.getElementById('modal-prise-service').classList.remove('hidden');
        }

        function closePriseServiceModal() {
            document.getElementById('modal-prise-service').classList.add('hidden');
            pendingPriseIndex = null;
        }

        function confirmerPriseService() {
            if (pendingPriseIndex === null) return;
            const index = pendingPriseIndex, s = sillonsState[index];
            if (!s || s.statut !== 'Libre') { closePriseServiceModal(); alert('Ce service n’est plus disponible.'); return; }
            s.statut = 'En Service'; s.conducteur = currentUser;
            closePriseServiceModal();
            sauvegarderStorage(true);
            entrerCabine(index);
        }

        function determinerVoieGare(gare, sillon) {
            if (gare === '*Stockage' || gare === '*Dépot') return '';
            if (sillon.ligne === 'pavillon') return (sillon.voies && sillon.voies[gare]) || '';
            if (gare === 'Fontaine') return sillon.voieFontaine || 'Voie A';
            if (gare === 'Ville') return sillon.voieVille || 'Voie A';
            return (ligneOrdre.indexOf(sillon.terminus) > ligneOrdre.indexOf(sillon.origine)) ? 'Voie A' : 'Voie B';
        }

function calculerHorairesParcours() {
    if (activeSillonIndex === null) return [];
    const sillon = sillonsState[activeSillonIndex];
    let [h, m] = sillon.depart.split(':').map(Number);
    let totalMin = h * 60 + m;
    
    const ligneOrdre = ligneDe(sillon).ordre, tempsTrajetSecondes = ligneDe(sillon).temps;
    let idxOrigine = ligneOrdre.indexOf(sillon.origine);
    let idxTerminus = ligneOrdre.indexOf(sillon.terminus);

    // --- CORRECTION SENS INVERSE ---
    // Si on va "à reculons" (ex: Ville vers *Dépot), on inverse le tableau de gares
    let direction = idxTerminus > idxOrigine ? 1 : -1;
    let sousLigne;
    
    if (direction === 1) {
        // Sens normal (Fontaine -> Ville)
        sousLigne = ligneOrdre.slice(idxOrigine, idxTerminus + 1);
    } else {
        // Sens inverse (Ville -> Fontaine) : on prend le slice et on inverse l'ordre
        sousLigne = ligneOrdre.slice(idxTerminus, idxOrigine + 1).reverse();
    }
    // -------------------------------

    let horairesTheoriques = [];
    let horairesReels = [];
    let secTheoriques = 0;
    let secReelles = 0;
    let decalageSec = (sillon.retard || 0) * 60;

    sousLigne.forEach((gare, idx) => {
        if (idx > 0) {
            let prevGare = sousLigne[idx - 1];
            
            // --- CORRECTION CLÉS DE TEMPS ---
            // On adapte la clé selon le sens pour trouver le bon temps de trajet
            let trajetKey = direction === 1 
                ? `${prevGare}->${gare}` 
                : `${gare}->${prevGare}`; // Inverse la clé si sens retour
            
            let trajetSec = tempsTrajetSecondes[trajetKey] || 0; // Si la clé n'existe pas, c'est 0 (tu devras ajouter les clés inversées dans ton objet tempsTrajetSecondes)
            
            secTheoriques += trajetSec;
            secReelles += trajetSec;
            
            if (sillon.arretsInter.includes(prevGare)) {
                let arretSec = (sillon.arretsDurees[prevGare] || 0) * 60;
                secTheoriques += arretSec;
                secReelles += arretSec;
            }
        }
        
        let totalSecTheo = (totalMin * 60) + secTheoriques;
        let totalSecReel = (totalMin * 60) + secReelles + decalageSec;

        // Format HH:MM (sans secondes)
        horairesTheoriques.push(`${String(Math.floor(totalSecTheo/3600)%24).padStart(2,'0')}:${String(Math.floor((totalSecTheo%3600)/60)).padStart(2,'0')}`);
        horairesReels.push(`${String(Math.floor(totalSecReel/3600)%24).padStart(2,'0')}:${String(Math.floor((totalSecReel%3600)/60)).padStart(2,'0')}`);
    });

    heureArriveeFinaleReelle = horairesReels[horairesReels.length - 1];
    heureArriveeFinaleTs = departTs(sillon) + (secReelles + decalageSec) * 1000;
    
    if (currentPlatform !== 'tel') {
        let [hD, mD] = sillon.depart.split(':').map(Number);
        let depSec = (hD * 60 + mD) * 60 + (sillon.retard || 0) * 60;
        let depReel = `${String(Math.floor(depSec/3600)%24).padStart(2,'0')}:${String(Math.floor((depSec%3600)/60)).padStart(2,'0')}`;
        document.getElementById('pc-cabine-horaires').innerText = `${depReel} ➔ ${heureArriveeFinaleReelle}`;
    }

    const container = document.getElementById(currentPlatform === 'tel' ? 'tel-cabine-parcours-list' : 'pc-cabine-parcours-list');
    container.innerHTML = '';

    sousLigne.forEach((gare, idx) => {
        let isOrigineTerminus = (idx === 0 || idx === sousLigne.length - 1);
        let isDesservi = isOrigineTerminus || sillon.arretsInter.includes(gare);
        if (!isDesservi) return;

        let voie = determinerVoieGare(gare, sillon);
        let arretTxt = (!isOrigineTerminus && sillon.arretsDurees[gare]) ? `${escapeHtml(sillon.arretsDurees[gare])} min d'arrêt` : '';
        let timeTheo = horairesTheoriques[idx];
        let timeReel = horairesReels[idx];
        let isDecale = (timeReel !== timeTheo);

        if (currentPlatform === 'tel') {
            container.innerHTML += `
                <div class="grid grid-cols-[55px_24px_1fr] items-start gap-2 relative">
                    <div class="bg-indigo-500/20 text-indigo-300 font-mono text-[11px] font-bold px-1.5 py-0.5 rounded text-center border border-indigo-400/30">${timeReel}</div>
                    <div class="flex flex-col items-center h-full relative"><div class="w-3.5 h-3.5 rounded-full bg-[#0B0E17] border-2 border-indigo-400 z-10 my-0.5"></div><div class="w-0.5 bg-indigo-500/40 flex-1 my-1"></div></div>
                    <div class="pb-3"><h4 class="font-extrabold text-base text-white">${escapeHtml(gare)}</h4>${voie ? `<div class="text-xs text-indigo-300">${escapeHtml(voie)}</div>`:''}${arretTxt ? `<div class="text-[11px] text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded inline-block mt-1 border border-amber-500/20">${escapeHtml(arretTxt)}</div>`:''}</div>
                </div>`;
        } else {
            let affichageHoraire = isDecale 
                ? `<span class="line-through text-gray-500 text-xs mr-2">${timeTheo}</span><span class="text-amber-400 font-bold">${timeReel}</span>`
                : `<span class="text-emerald-400 font-bold">${timeReel}</span>`;

            container.innerHTML += `
                <div class="relative flex items-center justify-between">
                    <div class="absolute -left-[31px] w-4 h-4 rounded-full bg-emerald-500 border-2 border-snck-card"></div>
                    <div>
                        <span class="font-bold text-base">${escapeHtml(gare)}</span>
                        <div class="text-xs text-gray-400">${escapeHtml(voie)} ${arretTxt ? `<span class="text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 ml-2">${escapeHtml(arretTxt)}</span>` : ''}</div>
                    </div>
                    <div class="text-right font-mono text-sm">${affichageHoraire}</div>
                </div>`;
        }
    });
    return horairesReels;
}
        function calculerRetardAutomatique(index) {
            const s = sillonsState[index];
            if (!s || s.isStarted || serviceAtteintTerminus) return;
            const auto = Math.max(0, Math.floor((Date.now() - departTs(s)) / 60000));
            const r = auto + (s.retardManuel || 0);
            if (r === s.retard && auto === s.retardAuto) return;
            s.retardAuto = auto; s.retard = r;
            sauvegarderStorage();
            if (index === activeSillonIndex) { calculerHorairesParcours(); mettreAJourAffichageRetard(); }
        }

        function mettreAJourAffichageRetard() {
            if (activeSillonIndex === null) return;
            const sillon = sillonsState[activeSillonIndex];
            let totalRetard = sillon.retard || 0;
            const pcRetard = document.getElementById('pc-cabine-retard');
            if (pcRetard) {
                if (totalRetard > 0) {
                    pcRetard.className = "text-xs font-semibold text-amber-400 mt-1";
                    pcRetard.innerText = `+${totalRetard} min (Retard)`;
                } else if (totalRetard < 0) {
                    pcRetard.className = "text-xs font-semibold text-blue-400 mt-1";
                    pcRetard.innerText = `${totalRetard} min (Avance)`;
                } else {
                    pcRetard.className = "text-xs font-semibold text-emerald-400 mt-1";
                    pcRetard.innerText = "+0 min (À l'heure)";
                }
            }
        }

        function verifierHeureDepartAtteinte() {
            const sillon = getActif();
            if (!sillon || sillon.isStarted) return;
            const ok = Date.now() >= departTs(sillon);
            const st = ok ? 'go' : 'wait:' + sillon.dateBrute + sillon.depart;
            document.querySelectorAll('.btn-commencer-conduite').forEach(btn => {
                if (btn.dataset.st === st) return;
                btn.dataset.st = st;
                const pc = btn.id === 'btn-commencer-pc';
                if (ok) {
                    btn.removeAttribute('disabled');
                    btn.className = pc ? "btn-commencer-conduite px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold cursor-pointer"
                        : "btn-commencer-conduite py-3 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-lg";
                    btn.innerHTML = `<i class="fa-solid fa-play"></i> Commencer le service`;
                } else {
                    btn.setAttribute('disabled', 'true');
                    btn.className = pc ? "btn-commencer-conduite px-4 py-2 rounded-xl bg-gray-800 text-gray-500 border border-gray-700 text-sm font-semibold cursor-not-allowed"
                        : "btn-commencer-conduite py-3 px-2 rounded-xl bg-gray-800 text-gray-500 border border-gray-700 text-xs font-bold flex items-center justify-center gap-1.5 cursor-not-allowed";
                    btn.innerHTML = `Départ à ${escapeHtml(sillon.depart)} (${escapeHtml(sillon.dateJJMM)})`;
                }
            });
        }

        function toggleCommencerConduite() {
            const s = getActif();
            if (!s || serviceAtteintTerminus) return;
            if (Date.now() < departTs(s)) { alert(`Impossible de démarrer : l'heure de départ (${s.depart}, ${s.dateJJMM}) n'est pas encore atteinte.`); return; }
            if (s.isStarted && !confirm('Remettre ce service à « non commencé » ?')) return;
            if (!s.isStarted) calculerRetardAutomatique(activeSillonIndex);
            s.isStarted = !s.isStarted;
            sauvegarderStorage(true);
            updateBoutonConduiteUI();
            mettreAJourAffichageRetard();
        }

        function updateBoutonConduiteUI() {
            const sillon = getActif();
            if (!sillon) return;
            if (!sillon.isStarted) { verifierHeureDepartAtteinte(); return; }
            document.querySelectorAll('.btn-commencer-conduite').forEach(btn => {
                btn.dataset.st = 'run';
                btn.removeAttribute('disabled');
                btn.className = btn.id === 'btn-commencer-pc'
                    ? "btn-commencer-conduite px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold cursor-pointer"
                    : "btn-commencer-conduite py-3 px-2 rounded-xl bg-blue-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-lg";
                btn.innerHTML = `<i class="fa-solid fa-train"></i> Train en route`;
            });
        }

        function verifierBoutonFinService() {
            if (!heureArriveeFinaleTs || serviceAtteintTerminus || Date.now() < heureArriveeFinaleTs) return;
            serviceAtteintTerminus = true;
            setFinEtat(true);
        }

        function openRetardModal() { document.getElementById('modal-retard').classList.remove('hidden'); }
        function closeRetardModal() { document.getElementById('modal-retard').classList.add('hidden'); }

        function handleSignalerRetardAvance(e) {
            e.preventDefault();
            const s = getActif(); if (!s) return;
            const mins = parseInt(document.getElementById('retard-minutes').value) || 0;
            const ancien = s.retardManuel || 0;
            if (s.retardAuto === undefined) s.retardAuto = Math.max(0, (s.retard || 0) - ancien);
            s.motifRetard = document.getElementById('retard-motif').value;
            s.retardManuel = document.getElementById('retard-type').value === 'avance' ? -mins : mins;
            s.retard = s.retardAuto + s.retardManuel;
            sauvegarderStorage();
            closeRetardModal();
            e.target.reset();
            mettreAJourAffichageRetard();
            calculerHorairesParcours();
        }

        function ouvrirFicheFinService() {
            const sillon = getActif(); if (!sillon) return;
            document.getElementById('fiche-numero').innerText = sillon.numero;
            document.getElementById('fiche-parcours').innerText = `${sillon.dateJJMM} • ${sillon.origine} ➔ ${sillon.terminus}`;
            document.getElementById('modal-fiche-fin').classList.remove('hidden');
        }

        function validerEtQuitterService() {
            if (activeSillonIndex !== null) {
                sillonsState.splice(activeSillonIndex, 1);
                sauvegarderStorage();
                activeSillonIndex = null;
            }
            document.getElementById('modal-fiche-fin').classList.add('hidden');
            document.getElementById('tel-btn-retour').style.display = 'flex';
            document.getElementById('pc-btn-retour').style.display = 'flex';
            openConduireModule(currentPlatform);
        }


        // ============================================================
        // FONCTIONNALITÉS AJOUTÉES
        // ============================================================

        // Détection plateforme : verrouiller par cadenas le mode inadapté à l'écran
        function detecterPlateforme() {
            const btnTel = document.getElementById('btn-mode-tel');
            const btnPc = document.getElementById('btn-mode-pc');
            const lockTel = document.getElementById('tel-lock-badge');
            const lockPc = document.getElementById('pc-lock-badge');
            const isPc = window.innerWidth >= 768; // Tablette et plus grand -> mode PC
            // Mode Téléphone verrouillé sur grand écran
            if (btnTel) {
                btnTel.classList.toggle('pointer-events-none', isPc);
                if (lockTel) lockTel.classList.toggle('hidden', !isPc);
            }
            // Mode PC verrouillé sur petit écran
            if (btnPc) {
                btnPc.classList.toggle('pointer-events-none', !isPc);
                if (lockPc) lockPc.classList.toggle('hidden', isPc);
            }
        }
        window.addEventListener('resize', detecterPlateforme);

        // Menu Horairiste & Perturbations
        function openHorairistePerturbations() {
            switchScreen('screen-hp-menu');
        }

        // Module Perturbations
        function openPerturbationsModule() {
            switchScreen('screen-perturbations');
            renderPerturbations();
        }

        // Gestion des perturbations (stockées dans localStorage)
        let perturbationsState = JSON.parse(localStorage.getItem('snck_perturbations')) || [];

        function handleSignalerPerturbation(e) {
            e.preventDefault();
            const nom = document.getElementById('perturbation-nom').value.trim();
            const type = document.getElementById('perturbation-type').value;
            const heureFin = document.getElementById('perturbation-heure-fin').value;
            const ligne = document.getElementById('perturbation-ligne').value;

            const perturbation = {
                id: uuid(),
                nom, type, heureFin, ligne,
                dateCreation: new Date().toLocaleString('fr-FR'),
                actif: true
            };

            perturbationsState.push(perturbation);
            localStorage.setItem('snck_perturbations', JSON.stringify(perturbationsState));

            // Synchroniser les perturbations avec les autres appareils.
            sauvegarderPerturbationsCloud();

            // Réinitialiser le formulaire
            document.getElementById('perturbation-nom').value = '';
            document.getElementById('perturbation-heure-fin').value = '';

            renderPerturbations();
            alert('Perturbation publiée sur le réseau !');
        }

        function sauvegarderPerturbationsCloud() { cloudSave(true); }

        function renderPerturbations() {
            const container = document.getElementById('liste-perturbations');
            if (!container) return;
            if (perturbationsState.length === 0) {
                container.innerHTML = '<div class="text-center py-8 bg-snck-card border border-snck-border rounded-2xl text-gray-400 text-sm">Aucune perturbation signalée.</div>';
                return;
            }
            container.innerHTML = '<h3 class="text-lg font-bold mb-3">Perturbations actives</h3>';
            perturbationsState.forEach((p, idx) => {
                const couleur = p.type === 'Interruption' ? 'red' : 'amber';
                container.innerHTML += `
                    <div class="bg-snck-card border border-${couleur}-500/30 rounded-xl p-4 flex justify-between items-center">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="px-2 py-0.5 rounded text-xs bg-${couleur}-500/10 text-${couleur}-400 border border-${couleur}-500/20 font-bold">${escapeHtml(p.type)}</span>
                                <span class="font-bold">${escapeHtml(p.nom)}</span>
                            </div>
                            <div class="text-xs text-gray-400">
                                <i class="fa-solid fa-route mr-1"></i> ${escapeHtml(p.ligne)} 
                                | <i class="fa-solid fa-clock mr-1"></i> Fin prévue : ${escapeHtml(p.heureFin)}
                                | <i class="fa-solid fa-calendar mr-1"></i> ${escapeHtml(p.dateCreation)}
                            </div>
                        </div>
                        <button onclick="supprimerPerturbation(${idx})" class="px-3 py-1.5 bg-red-500/10 text-red-400 text-xs rounded-lg hover:bg-red-500/20 cursor-pointer shrink-0 ml-3">
                            <i class="fa-solid fa-trash mr-1"></i> Retirer
                        </button>
                    </div>`;
            });
        }

        function supprimerPerturbation(idx) {
            if (confirm('Retirer cette perturbation ?')) {
                perturbationsState.splice(idx, 1);
                localStorage.setItem('snck_perturbations', JSON.stringify(perturbationsState));
                sauvegarderPerturbationsCloud();
                renderPerturbations();
            }
        }

        // Supprimer le Service depuis la Cabine
        function supprimerService() {
            if (!confirm('Supprimer ce service ? Le sillon restera visible jusqu\'à son heure d\'arrivée au terminus, mais sera marqué comme supprimé.')) return;

            if (activeSillonIndex !== null) {
                let sillon = sillonsState[activeSillonIndex];
                // Marquer comme supprimé au lieu de le retirer
                sillon.statut = 'Supprimé';
                sillon.serviceSupprime = true;
                sauvegarderStorage();
                activeSillonIndex = null;
            }

            // Réafficher les boutons retour
            document.getElementById('tel-btn-retour').style.display = 'flex';
            document.getElementById('pc-btn-retour').style.display = 'flex';
            openConduireModule(currentPlatform);
        }

        function uuid() { return crypto.randomUUID ? crypto.randomUUID() : 'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10); }
        function copierTexte(t) { (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(() => prompt('Copie manuelle :', t)); }
        function viderCachesLocaux() {
            sillonsState = []; perturbationsState = []; activeSillonIndex = null;
            localStorage.removeItem('snck_sillons'); localStorage.removeItem('snck_perturbations');
        }
        function getActif() { return activeSillonIndex === null ? null : (sillonsState[activeSillonIndex] || null); }
        // Horodatage réel du départ (date + heure) : évite les erreurs de jour / minuit
        function departTs(s) {
            const [h, m] = String(s.depart).split(':').map(Number);
            const d = s.dateBrute ? new Date(s.dateBrute + 'T00:00:00') : new Date();
            d.setHours(h, m, 0, 0);
            return d.getTime();
        }
        function dureeSec(s) {
            const ligneOrdre = ligneDe(s).ordre, tempsTrajetSecondes = ligneDe(s).temps;
            const a = ligneOrdre.indexOf(s.origine), b = ligneOrdre.indexOf(s.terminus), dir = b > a ? 1 : -1;
            const g = dir > 0 ? ligneOrdre.slice(a, b + 1) : ligneOrdre.slice(b, a + 1).reverse();
            let t = 0;
            for (let i = 1; i < g.length; i++) {
                t += tempsTrajetSecondes[dir > 0 ? `${g[i-1]}->${g[i]}` : `${g[i]}->${g[i-1]}`] || 0;
                if ((s.arretsInter || []).includes(g[i-1])) t += ((s.arretsDurees || {})[g[i-1]] || 0) * 60;
            }
            return t;
        }
        function setFinEtat(on) {
            document.querySelectorAll('#pc-btn-fin-service, #tel-btn-b3').forEach(b => {
                b.disabled = !on;
                ['bg-blue-600', 'hover:bg-blue-500', 'text-white', 'cursor-pointer'].forEach(c => b.classList.toggle(c, on));
                ['bg-gray-800', 'text-gray-500', 'cursor-not-allowed'].forEach(c => b.classList.toggle(c, !on));
            });
            document.querySelectorAll('.fin-service-timer').forEach(t => t.innerText = on ? `Prêt (${heureArriveeFinaleReelle})` : 'En attente');
        }
        function entrerCabine(index) {
            activeSillonIndex = index;
            const sillon = sillonsState[index];
            serviceAtteintTerminus = false; heureArriveeFinaleTs = null; heureArriveeFinaleReelle = null;
            setFinEtat(false);
            document.querySelectorAll('.btn-commencer-conduite').forEach(b => b.dataset.st = '');
            document.getElementById('tel-btn-retour').style.display = 'none';
            document.getElementById('pc-btn-retour').style.display = 'none';
            if (currentPlatform === 'tel') {
                switchScreen('screen-cabine-tel');
                document.getElementById('tel-cabine-titre').innerText = `Train ${sillon.numero}`;
                document.getElementById('tel-cabine-sous-titre').innerText = `Destination ${sillon.terminus}`;
                document.getElementById('tel-cabine-date-comp').innerText = `${sillon.dateJJMM} • ${sillon.composition}`;
            } else {
                switchScreen('screen-cabine-pc');
                document.getElementById('pc-cabine-numero').innerText = sillon.numero;
                document.getElementById('pc-cabine-titre').innerText = `${sillon.origine} ➔ ${sillon.terminus}`;
                document.getElementById('pc-cabine-date').innerText = `Date : ${sillon.dateJJMM} • Conducteur : ${currentUser}`;
            }
            updateBoutonConduiteUI();
            calculerRetardAutomatique(index);
            calculerHorairesParcours();
            verifierHeureDepartAtteinte();
        }
        function reprendreService(index) {
            const s = sillonsState[index];
            if (s && s.statut === 'En Service' && (s.conducteur || currentUser) === currentUser) { s.conducteur = currentUser; entrerCabine(index); }
        }
        // Les services supprimés disparaissent une fois l'heure d'arrivée passée
        function purgerSillonsSupprimes() {
            const now = Date.now(), act = getActif();
            const keep = sillonsState.filter(s => !(s.serviceSupprime && now > departTs(s) + ((s.retard || 0) * 60 + dureeSec(s)) * 1000));
            if (keep.length === sillonsState.length) return;
            sillonsState = keep;
            activeSillonIndex = act ? sillonsState.indexOf(act) : null;
            if (activeSillonIndex === -1) activeSillonIndex = null;
            sauvegarderStorage(); renderSillons(); renderSillonsConduite();
        }
        setInterval(() => { if (currentUser && cloudReady) purgerSillonsSupprimes(); }, 30000);

        function deleteSillon(index) {
            if (confirm("Supprimer ce sillon ?")) {
                sillonsState.splice(index, 1);
                sauvegarderStorage();
                renderSillons();
            }
        }
    